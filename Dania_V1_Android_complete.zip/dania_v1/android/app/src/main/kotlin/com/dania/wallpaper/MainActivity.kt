package com.dania.wallpaper

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
