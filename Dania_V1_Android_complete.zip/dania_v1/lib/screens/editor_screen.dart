import 'dart:typed_data';
import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_wallpaper_plus/flutter_wallpaper_plus.dart';
import 'package:path_provider/path_provider.dart';

import '../services/gallery_service.dart';
import '../services/wallpaper_service.dart';
import '../theme.dart';

class EditorScreen extends StatefulWidget {
  final Uint8List imageBytes;
  const EditorScreen({super.key, required this.imageBytes});

  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen> {
  final GlobalKey previewKey = GlobalKey();
  String text = '';
  Color textColor = Colors.white;
  double textSize = 28;
  int filter = 0;
  int frame = 0;
  bool busy = false;

  final filters = const ['Original', 'Clair', 'Vivid', 'Noir & Blanc', 'Nuit'];
  final colors = const [Colors.white, Color(0xFF18D9FF), Color(0xFFFFD54F), Color(0xFFFF5D8F), Color(0xFFB388FF), Colors.black];

  ColorFilter? get colorFilter {
    switch (filter) {
      case 1:
        return const ColorFilter.matrix(<double>[
          1.10, 0, 0, 0, 8, 0, 1.10, 0, 0, 8, 0, 0, 1.10, 0, 8, 0, 0, 0, 1, 0,
        ]);
      case 2:
        return const ColorFilter.matrix(<double>[
          1.25, 0, 0, 0, -18, 0, 1.25, 0, 0, -18, 0, 0, 1.25, 0, -18, 0, 0, 0, 1, 0,
        ]);
      case 3:
        return const ColorFilter.matrix(<double>[
          .2126, .7152, .0722, 0, 0, .2126, .7152, .0722, 0, 0, .2126, .7152, .0722, 0, 0, 0, 0, 0, 1, 0,
        ]);
      case 4:
        return const ColorFilter.matrix(<double>[
          .65, 0, 0, 0, 0, 0, .75, 0, 0, 0, 0, 0, 1.05, 0, 0, 0, 0, 0, 1, 0,
        ]);
      default:
        return null;
    }
  }

  Future<Uint8List?> capture() async {
    final boundary = previewKey.currentContext?.findRenderObject() as RenderRepaintBoundary?;
    if (boundary == null) return null;
    final image = await boundary.toImage(pixelRatio: 3);
    final data = await image.toByteData(format: ui.ImageByteFormat.png);
    return data?.buffer.asUint8List();
  }

  Future<void> save() async {
    setState(() => busy = true);
    try {
      final bytes = await capture();
      if (bytes == null) throw Exception('Prévisualisation indisponible');
      final ok = await GalleryService.savePng(bytes);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(ok ? 'Création enregistrée dans la galerie.' : 'Enregistrement non confirmé.')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Erreur : $e')));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> setWallpaper() async {
    setState(() => busy = true);
    File? file;
    try {
      final target = await showModalBottomSheet<WallpaperTarget>(
        context: context,
        builder: (_) => SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Padding(
                padding: EdgeInsets.all(18),
                child: Text('Définir comme fond d’écran', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              ),
              ListTile(
                leading: const Icon(Icons.home),
                title: const Text('Écran d’accueil'),
                onTap: () => Navigator.pop(context, WallpaperTarget.home),
              ),
              ListTile(
                leading: const Icon(Icons.lock),
                title: const Text('Écran de verrouillage'),
                onTap: () => Navigator.pop(context, WallpaperTarget.lock),
              ),
              ListTile(
                leading: const Icon(Icons.smartphone),
                title: const Text('Les deux'),
                onTap: () => Navigator.pop(context, WallpaperTarget.both),
              ),
            ],
          ),
        ),
      );
      if (target == null) return;

      final bytes = await capture();
      if (bytes == null) throw Exception('Prévisualisation indisponible');
      final dir = await getTemporaryDirectory();
      file = File('${dir.path}/dania_wallpaper_${DateTime.now().millisecondsSinceEpoch}.png');
      await file.writeAsBytes(bytes, flush: true);

      final result = await FlutterWallpaperPlus.setImageWallpaper(
        source: WallpaperSource.file(file.path),
        target: target,
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(result.success ? 'Fond d’écran appliqué.' : 'Échec : ${result.message}')),
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Erreur : $e')));
      }
    } finally {
      if (file != null) {
        try { await file.delete(); } catch (_) {}
      }
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Éditeur'), actions: [IconButton(onPressed: busy ? null : save, icon: const Icon(Icons.download))]),
      body: Column(children: [
        Expanded(child: Center(child: RepaintBoundary(key: previewKey, child: AspectRatio(aspectRatio: 9 / 16, child: Container(
          margin: const EdgeInsets.all(16),
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(28), border: frame == 0 ? null : Border.all(color: frame == 1 ? DaniaTheme.cyan : Colors.white, width: 6), boxShadow: [BoxShadow(color: DaniaTheme.cyan.withOpacity(.15), blurRadius: 30)]),
          clipBehavior: Clip.antiAlias,
          child: Stack(fit: StackFit.expand, children: [
            if (colorFilter == null) Image.memory(widget.imageBytes, fit: BoxFit.cover) else ColorFiltered(colorFilter: colorFilter!, child: Image.memory(widget.imageBytes, fit: BoxFit.cover)),
            if (text.trim().isNotEmpty) Center(child: Container(padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10), decoration: BoxDecoration(color: Colors.black.withOpacity(.25), borderRadius: BorderRadius.circular(14)), child: Text(text, textAlign: TextAlign.center, style: TextStyle(color: textColor, fontSize: textSize, fontWeight: FontWeight.w700, shadows: const [Shadow(blurRadius: 5, color: Colors.black)])))),
            if (frame == 2) Positioned.fill(child: IgnorePointer(child: CustomPaint(painter: _NeonFramePainter()))),
          ]),
        )))),
        Container(color: const Color(0xFF06111F), padding: const EdgeInsets.fromLTRB(12, 8, 12, 14), child: SingleChildScrollView(child: Column(children: [
          SizedBox(height: 52, child: ListView(scrollDirection: Axis.horizontal, children: [
            _tool('Texte', Icons.text_fields, () => _textDialog()),
            _tool('Couleur', Icons.palette, () => _colorDialog()),
            _tool('Filtres', Icons.auto_awesome, () => _filterDialog()),
            _tool('Cadres', Icons.crop_square, () => _frameDialog()),
            _tool('Fond', Icons.wallpaper, setWallpaper),
          ])),
          const SizedBox(height: 6),
          if (text.isNotEmpty) Slider(value: textSize, min: 14, max: 60, onChanged: (v) => setState(() => textSize = v)),
          SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: busy ? null : save, icon: const Icon(Icons.save), label: Text(busy ? 'Traitement...' : 'Enregistrer en HD'))),
        ]))),
      ]),
    );
  }

  Widget _tool(String label, IconData icon, VoidCallback onTap) => Padding(padding: const EdgeInsets.symmetric(horizontal: 4), child: OutlinedButton.icon(onPressed: onTap, icon: Icon(icon, size: 18), label: Text(label)));

  Future<void> _textDialog() async {
    final controller = TextEditingController(text: text);
    final result = await showDialog<String>(context: context, builder: (_) => AlertDialog(title: const Text('Ajouter du texte'), content: TextField(controller: controller, autofocus: true, maxLines: 3, decoration: const InputDecoration(hintText: 'Ton texte...')), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Annuler')), FilledButton(onPressed: () => Navigator.pop(context, controller.text), child: const Text('Ajouter'))]));
    if (result != null) setState(() => text = result);
  }

  Future<void> _colorDialog() async { await showModalBottomSheet(context: context, builder: (_) => Wrap(children: colors.map((c) => ListTile(leading: CircleAvatar(backgroundColor: c), title: Text(c == Colors.white ? 'Blanc' : 'Couleur'), onTap: () { setState(() => textColor = c); Navigator.pop(context); })).toList())); }
  Future<void> _filterDialog() async { await showModalBottomSheet(context: context, builder: (_) => Wrap(children: List.generate(filters.length, (i) => ListTile(title: Text(filters[i]), trailing: i == filter ? const Icon(Icons.check) : null, onTap: () { setState(() => filter = i); Navigator.pop(context); })))); }
  Future<void> _frameDialog() async { await showModalBottomSheet(context: context, builder: (_) => Wrap(children: [0,1,2].map((i) => ListTile(title: Text(['Aucun','Cyan','Néon'][i]), trailing: i == frame ? const Icon(Icons.check) : null, onTap: () { setState(() => frame = i); Navigator.pop(context); })).toList())); }
}

class _NeonFramePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()..style = PaintingStyle.stroke..strokeWidth = 5..shader = const LinearGradient(colors: [DaniaTheme.cyan, DaniaTheme.violet, DaniaTheme.cyan]).createShader(Offset.zero & size);
    canvas.drawRRect(RRect.fromRectAndRadius(Offset.zero & size, const Radius.circular(28)), p);
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
