import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';

import 'screens/editor_screen.dart';
import 'theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const DaniaApp());
}

class DaniaApp extends StatelessWidget {
  const DaniaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Danîa✨',
      theme: DaniaTheme.dark(),
      home: const DaniaShell(),
    );
  }
}

class DaniaShell extends StatefulWidget {
  const DaniaShell({super.key});
  @override
  State<DaniaShell> createState() => _DaniaShellState();
}

class _DaniaShellState extends State<DaniaShell> {
  int index = 0;
  final picker = ImagePicker();
  final List<String> categories = const [
    'Tendances', 'Nature', 'Couples', 'Anime', 'Voitures', 'Abstrait',
    'Gaming', 'Citations', 'Minimaliste'
  ];

  Future<void> pick(ImageSource source) async {
    final x = await picker.pickImage(source: source, imageQuality: 95);
    if (x == null || !mounted) return;
    final bytes = await x.readAsBytes();
    Navigator.push(context, MaterialPageRoute(builder: (_) => EditorScreen(imageBytes: bytes)));
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _home(),
      _categories(),
      _create(),
      _favorites(),
      _profile(),
    ];
    return Scaffold(
      body: SafeArea(child: pages[index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => setState(() => index = i),
        backgroundColor: const Color(0xFF06111F),
        indicatorColor: DaniaTheme.cyan.withOpacity(.18),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Accueil'),
          NavigationDestination(icon: Icon(Icons.grid_view_outlined), selectedIcon: Icon(Icons.grid_view), label: 'Catégories'),
          NavigationDestination(icon: Icon(Icons.add_circle_outline), selectedIcon: Icon(Icons.add_circle), label: 'Créer'),
          NavigationDestination(icon: Icon(Icons.favorite_border), selectedIcon: Icon(Icons.favorite), label: 'Favoris'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profil'),
        ],
      ),
    );
  }

  Widget _header() => Padding(
        padding: const EdgeInsets.fromLTRB(20, 14, 20, 8),
        child: Row(children: [
          Image.asset('assets/images/dania_logo.png', width: 58, height: 58),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Danîa✨', style: GoogleFonts.cinzel(fontSize: 23, fontWeight: FontWeight.w700)),
            Text('Ton style, ton écran, ton univers.', style: GoogleFonts.caveat(color: Colors.white70, fontSize: 16)),
          ])),
          IconButton(onPressed: () {}, icon: const Icon(Icons.search)),
        ]),
      );

  Widget _home() => ListView(
        padding: EdgeInsets.zero,
        children: [
          _header(),
          Container(
            margin: const EdgeInsets.fromLTRB(16, 8, 16, 18),
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(28),
              gradient: const LinearGradient(colors: [Color(0xFF062A45), Color(0xFF111B5B)]),
              border: Border.all(color: DaniaTheme.cyan.withOpacity(.35)),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Crée ton fond unique', style: GoogleFonts.cinzel(fontSize: 24, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              const Text('Transforme une photo en fond d’écran personnalisé avec Danîa✨.'),
              const SizedBox(height: 18),
              Row(children: [
                Expanded(child: FilledButton.icon(onPressed: () => pick(ImageSource.gallery), icon: const Icon(Icons.photo_library), label: const Text('Galerie'))),
                const SizedBox(width: 10),
                Expanded(child: OutlinedButton.icon(onPressed: () => pick(ImageSource.camera), icon: const Icon(Icons.camera_alt), label: const Text('Photo'))),
              ]),
            ]),
          ),
          Padding(padding: const EdgeInsets.symmetric(horizontal: 20), child: Text('Catégories', style: GoogleFonts.cinzel(fontSize: 20, fontWeight: FontWeight.bold))),
          const SizedBox(height: 10),
          SizedBox(height: 118, child: ListView.separated(
            padding: const EdgeInsets.symmetric(horizontal: 16), scrollDirection: Axis.horizontal,
            itemCount: categories.length, separatorBuilder: (_, __) => const SizedBox(width: 10),
            itemBuilder: (_, i) => Container(width: 105, decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [DaniaTheme.blue.withOpacity(.7), DaniaTheme.violet.withOpacity(.35)])), child: Center(child: Padding(padding: const EdgeInsets.all(8), child: Text(categories[i], textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w700))))),
          )),
          const SizedBox(height: 20),
          Padding(padding: const EdgeInsets.symmetric(horizontal: 20), child: Text('Danîa✨ V1', style: GoogleFonts.cinzel(fontSize: 20, fontWeight: FontWeight.bold))),
          const Padding(padding: EdgeInsets.fromLTRB(20, 8, 20, 24), child: Text('Galerie • Texte • Couleurs • Filtres • Cadres • Stickers • HD • Fond d’écran', style: TextStyle(color: Colors.white70))),
        ],
      );

  Widget _categories() => ListView(padding: const EdgeInsets.all(18), children: [
    Text('Catégories', style: GoogleFonts.cinzel(fontSize: 28, fontWeight: FontWeight.bold)),
    const SizedBox(height: 6), const Text('Choisis une ambiance pour ton prochain écran.', style: TextStyle(color: Colors.white70)),
    const SizedBox(height: 18),
    ...categories.map((c) => Card(color: DaniaTheme.panel, child: ListTile(leading: CircleAvatar(backgroundColor: DaniaTheme.blue.withOpacity(.2), child: const Icon(Icons.wallpaper)), title: Text(c), trailing: const Icon(Icons.chevron_right), onTap: () => _showCategoryInfo(c)))),
  ]);


  void _showCategoryInfo(String category) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Catégorie « $category » — catalogue en ligne prévu dans une prochaine version.')),
    );
  }

  Widget _create() => Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
    Image.asset('assets/images/dania_logo.png', width: 120),
    const SizedBox(height: 18),
    Text('Créer avec Danîa✨', style: GoogleFonts.cinzel(fontSize: 26, fontWeight: FontWeight.bold)),
    const SizedBox(height: 20),
    FilledButton.icon(onPressed: () => pick(ImageSource.gallery), icon: const Icon(Icons.photo_library), label: const Text('Choisir une photo')),
    const SizedBox(height: 10),
    OutlinedButton.icon(onPressed: () => pick(ImageSource.camera), icon: const Icon(Icons.camera_alt), label: const Text('Prendre une photo')),
  ])));

  Widget _favorites() => const Center(child: Text('Aucun favori pour le moment\n\nTes créations favorites apparaîtront ici.', textAlign: TextAlign.center));
  Widget _profile() => ListView(padding: const EdgeInsets.all(22), children: [
    Center(child: Image.asset('assets/images/dania_logo.png', width: 110)),
    const SizedBox(height: 12),
    Center(child: Text('Danîa✨', style: GoogleFonts.cinzel(fontSize: 28, fontWeight: FontWeight.bold))),
    const SizedBox(height: 25),
    const Card(child: ListTile(leading: Icon(Icons.hd), title: Text('Export HD'), subtitle: Text('Qualité maximale pour tes créations.'))),
    const Card(child: ListTile(leading: Icon(Icons.info_outline), title: Text('À propos'), subtitle: Text('Danîa✨ — Ton style, ton écran, ton univers.'))),
  ]);
}
