# Danîa✨ V1 — Android complet

Cette version transforme la base Flutter V1 en projet Android installable et testable.

## Identifiant Android

- Application ID / package : `com.dania.wallpaper`
- Nom affiché : `Danîa✨`
- Version : `1.0.0+1`
- Android minimum : API 24

## Préparer la machine

1. Installer Flutter stable et Android Studio.
2. Ouvrir le dossier `dania_v1` comme projet Flutter.
3. Vérifier :

```bash
flutter doctor
flutter pub get
flutter analyze
```

Si le SDK Android n'est pas encore configuré :

```bash
flutter doctor --android-licenses
```

## Générer l'APK de test

Un APK de test/release peut être construit avec :

```bash
flutter build apk --release
```

Le fichier attendu est sous `build/app/outputs/flutter-apk/`.

Pour installer directement sur un téléphone USB avec le débogage USB activé :

```bash
flutter devices
flutter install
```

## Google Play

Pour générer le paquet Play :

```bash
flutter build appbundle --release
```

Le fichier attendu est sous `build/app/outputs/bundle/release/`.

Avant une publication réelle, configure une clé de signature de production. Le fichier `android/key.properties.example` montre le format attendu. Ne publie jamais la clé privée, `key.properties` ou ses mots de passe dans Git.

## Ce qui a été préparé

- dossier `android/` complet pour Flutter
- `applicationId` `com.dania.wallpaper`
- activité Android Kotlin
- manifeste avec caméra, galerie/média et fond d'écran
- icône/écran de lancement Danîa✨
- configuration Gradle/AndroidX/Kotlin
- configuration de signature locale/CI
- SDK Dart minimal aligné sur les dépendances V1 actuelles
- corrections mineures de code et nettoyage des fichiers temporaires de fond d'écran

## Limitation importante

L'environnement qui a servi à préparer cette archive ne contient pas le SDK Flutter/Dart. La compilation finale n'a donc pas pu être exécutée ici. La première étape sur ta machine ou dans Codemagic doit être `flutter pub get` puis `flutter analyze`, suivie de `flutter build apk --release`.
