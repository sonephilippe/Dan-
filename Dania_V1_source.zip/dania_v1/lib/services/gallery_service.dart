import 'dart:typed_data';
import 'package:image_gallery_saver_plus/image_gallery_saver_plus.dart';

class GalleryService {
  static Future<bool> savePng(Uint8List bytes) async {
    final result = await ImageGallerySaverPlus.saveImage(
      bytes,
      quality: 100,
      name: 'dania_${DateTime.now().millisecondsSinceEpoch}',
    );
    if (result is Map) return result['isSuccess'] == true || result['success'] == true;
    return result != null;
  }
}
