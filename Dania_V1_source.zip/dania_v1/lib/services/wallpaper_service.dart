import 'package:flutter_wallpaper_plus/flutter_wallpaper_plus.dart';

class WallpaperService {
  static Future<WallpaperResult> setFromFile(String path, WallpaperTarget target) =>
      FlutterWallpaperPlus.setImageWallpaper(
        source: WallpaperSource.file(path),
        target: target,
      );
}
