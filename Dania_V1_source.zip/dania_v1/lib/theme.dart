import 'package:flutter/material.dart';

class DaniaTheme {
  static const bg = Color(0xFF020812);
  static const panel = Color(0xFF071728);
  static const cyan = Color(0xFF16D9FF);
  static const blue = Color(0xFF168BFF);
  static const violet = Color(0xFF765CFF);
  static const white = Color(0xFFF5FBFF);

  static ThemeData dark() => ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bg,
        colorScheme: const ColorScheme.dark(
          primary: cyan,
          secondary: violet,
          surface: panel,
        ),
        useMaterial3: true,
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: panel,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide.none,
          ),
        ),
      );
}
